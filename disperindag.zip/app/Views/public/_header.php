<header id="header" class="full-header">
    <div id="header-wrap">
        <div class="container">
            <div class="header-row">
                <div id="logo">
                    <a href="index.html" class="standard-logo" data-dark-logo="<?= base_url() ?>/public/files/web-assets/inhil.png"><img src="<?= base_url() ?>/public/files/web-assets/inhil.png" alt=""></a>
                    <a href="index.html" class="retina-logo" data-dark-logo="<?= base_url() ?>/public/files/web-assets/inhil-2x.png"><img src="<?= base_url() ?>/public/files/web-assets/inhil-2x.png" alt=""></a>
                </div>
                <div class="header-misc">

                </div>
                <div id="primary-menu-trigger">
                    <svg class="svg-trigger" viewBox="0 0 100 100">
                        <path d="m 30,33 h 40 c 3.722839,0 7.5,3.126468 7.5,8.578427 0,5.451959 -2.727029,8.421573 -7.5,8.421573 h -20"></path>
                        <path d="m 30,50 h 40"></path>
                        <path d="m 70,67 h -40 c 0,0 -7.5,-0.802118 -7.5,-8.365747 0,-7.563629 7.5,-8.634253 7.5,-8.634253 h 20"></path>
                    </svg>
                </div>
                <nav class="primary-menu">
                    <ul class="menu-container">
                        <li class="menu-item">
                            <a class="menu-link <?= ($panel == 'home' ? "color" : "") ?>" href="<?= base_url('/') ?>">Home</a>
                        </li>
                        <li class="menu-item">
                            <a class="menu-link" href="javscript:;">
                                <div>Profil</div>
                            </a>
                            <ul class="sub-menu-container">
                                <li class="menu-item">
                                    <a class="menu-link" href="#">
                                        <div>Visi & Misi</div>
                                    </a>
                                </li>
                                <li class="menu-item">
                                    <a class="menu-link" href="#">
                                        <div>Struktur Organisasi</div>
                                    </a>
                                </li>
                                <li class="menu-item">
                                    <a class="menu-link" href="#">
                                        <div>Kepala Dinas</div>
                                    </a>
                                </li>
                                <li class="menu-item">
                                    <a class="menu-link" href="#">
                                        <div>Sekretaris</div>
                                    </a>
                                </li>
                                <li class="menu-item">
                                    <a class="menu-link" href="#">
                                        <div>Bidang 1</div>
                                    </a>
                                </li>
                                <li class="menu-item">
                                    <a class="menu-link" href="#">
                                        <div>Bidang 2</div>
                                    </a>
                                </li>
                                <li class="menu-item">
                                    <a class="menu-link" href="#">
                                        <div>Bidang 3</div>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu-item">
                            <a class="menu-link <?= ($panel == 'komoditas' ? "color" : "") ?>" href="javscript:;">
                                <div>Harga Komoditas</div>
                            </a>
                            <ul class="sub-menu-container">
                                <li class="menu-item">
                                    <a class="menu-link" href="<?= base_url('/komoditas') ?>">
                                        <div>Komoditas Pangan</div>
                                    </a>
                                </li>
                                <li class="menu-item">
                                    <a class="menu-link" href="">
                                        <div>Barang Penting</div>
                                    </a>
                                </li>
                                <li class="menu-item">
                                    <a class="menu-link" href="">
                                        <div>Barang Penting Lainnya</div>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu-item">
                            <a class="menu-link <?= ($panel == 'data-pasar' ? "color" : "") ?>" href="<?= base_url('/pasar') ?>">Data Pasar</a>
                        </li>
                        <li class="menu-item">
                            <a class="menu-link <?php if ($panel == 'statistik_wilayah' || $panel == 'statistik_komoditas') {
                                                    echo "text-success";
                                                } ?>" href="javascript:;">
                                <div>Statistik</div>
                            </a>
                            <ul class="sub-menu-container">
                                <li class="menu-item">
                                    <a class="menu-link <?php if ($panel == 'statistik_wilayah') {
                                                            echo "text-success";
                                                        } ?>" href="<?= base_url('/statistik-wilayah') ?>">Statistik Per Wilayah</a>
                                </li>
                                <li class="menu-item">
                                    <a class="menu-link <?php if ($panel == 'statistik_komoditas') {
                                                            echo "text-success";
                                                        } ?>" href="<?= base_url('/statistik-komoditas') ?>">Statistik Per Komoditas</a>
                                </li>
                            </ul>
                        </li>
                        <li class="menu-item">
                            <a class="menu-link <?php if ($panel == 'artikel') {
                                                    echo "text-success";
                                                } ?>" href="<?= base_url('/artikel') ?>">Artikel</a>
                        </li>
                        <li class="menu-item">
                            <a class="menu-link <?php if ($panel == 'kontak') {
                                                    echo "text-success";
                                                } ?>" href="<?= base_url('/kontak') ?>">Kontak</a>
                        </li>
                        <li class="menu-item">
                            <a class="menu-link <?php if ($panel == 'kontak') {
                                                    echo "text-success";
                                                } ?>" href="<?= base_url('/kontak') ?>">Index Kepuasan</a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>
    <div class="header-wrap-clone"></div>
</header>