<script src="<?=base_url()?>/public/assets/user/js/jquery.js"></script>
<script src="<?=base_url()?>/public/assets/user/js/plugins.min.js"></script>
<script src="<?=base_url()?>/public/assets/user/js/plugins.jpaginate.js"></script>
<!-- <script src="<?=base_url()?>/public/assets/user/js/components/bs-datatable.js"></script> -->
<script src="<?=base_url()?>/public/assets/user/js/components/datepicker.js"></script>

<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.12.1/r-2.3.0/datatables.min.js"></script>
<script src="<?=base_url()?>/public/assets/user/js/functions.js"></script>
