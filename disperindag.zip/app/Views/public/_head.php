<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="author" content="SemiColonWeb" />
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,400i,700|Poppins:300,400,500,600,700|PT+Serif:400,400i&display=swap" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="<?= base_url() ?>/public/assets/user/css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="<?= base_url() ?>/public/assets/user/style.css" type="text/css" />
	<link rel="stylesheet" href="<?= base_url() ?>/public/assets/user/css/dark.css" type="text/css" />
	<link rel="stylesheet" href="<?= base_url() ?>/public/assets/user/css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="<?= base_url() ?>/public/assets/user/css/animate.css" type="text/css" />
	<link rel="stylesheet" href="<?= base_url() ?>/public/assets/user/css/magnific-popup.css" type="text/css" />
	<!-- <link rel="stylesheet" href="<?= base_url() ?>/public/assets/user/css/components/bs-datatable.css" type="text/css" /> -->
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.12.1/r-2.3.0/datatables.min.css" />

	<link rel="stylesheet" href="<?= base_url() ?>/public/assets/user/css/components/select-boxes.css" type="text/css" />
	<link rel="stylesheet" href="<?= base_url() ?>/public/assets/user/css/components/datepicker.css" type="text/css">
	<link rel="stylesheet" href="<?= base_url() ?>/public/assets/user/css/custom.css" type="text/css" />
	<link href="<?= base_url() ?>/public/assets/fontawesome/css/all.min.css" rel="stylesheet" />
	<link href="<?= base_url() ?>/public/assets/fontawesome/css/fontawesome.min.css" rel="stylesheet" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title><?= $title ?> | Pangan Inhil</title>
</head>