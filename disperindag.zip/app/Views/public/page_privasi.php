<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<?= view('public/_head') ?>

<body class="stretched">
    <div id="wrapper" class="clearfix">
        <?= view('public/_header') ?>
        <section id="page-title" class="page-title-parallax page-title-dark" style="background-image: url('<?= base_url() ?>/public/files/web-assets/paralax.png'); padding: 120px 0;" data-bottom-top="background-position:0px 300px;" data-top-bottom="background-position:0px -300px;">
            <div class="container clearfix">
                <h1 class="mt-3 mb-0">Informasi Pangan</h1>
                <span class="mt-0">Indragiri Hilir</span>
                <ol class="breadcrumb">
                    <!-- <li class=""><img src="<?= base_url() ?>/public/files/web-assets/logo-anka.png" width="80px" alt=""></li> -->
                    <li class="ms-2"><img src="<?= base_url() ?>/public/files/web-assets/logo-inhil.png" width="60px" alt=""></li>
                    <!-- <li class="breadcrumb-item"><a href="#">Pages</a></li>
					<li class="breadcrumb-item active" aria-current="page">Jobs</li> -->
                </ol>
            </div>

        </section>
        <section id="content">
            <div class="content-wrap">
                <div class="container clearfix">
                    <div class="fancy-title title-bottom-border mb-0">
                        <h3>Kebijakan Privasi</h3>
                    </div>

                </div>
            </div>
    </div>

    </section>

    <?= view('public/_footer'); ?>
    </div>
    <div id="gotoTop" class="icon-angle-up"></div>
    <?= view('public/_footer_js') ?>
</body>

</html>