<base href="">
<meta charset="utf-8" />
<title><?= $title; ?> - Diperindag Inhil</title>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
<link href="<?= base_url('/public/assets/admin/css/pages/wizard/wizard-6.css') ?>" rel="stylesheet" type="text/css" />
<link href="<?= base_url() ?>/public/assets/admin/plugins/custom/datatables/datatables.bundle.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url() ?>/public/assets/admin/plugins/custom/fullcalendar/fullcalendar.bundle.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url() ?>/public/assets/admin/plugins/global/plugins.bundle.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url() ?>/public/assets/admin/plugins/custom/prismjs/prismjs.bundle.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url() ?>/public/assets/admin/css/style.bundle.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url() ?>/public/assets/admin/css/themes/layout/header/base/light.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url() ?>/public/assets/admin/css/themes/layout/header/menu/light.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url() ?>/public/assets/admin/css/themes/layout/brand/dark.css" rel="stylesheet" type="text/css" />
<link href="<?= base_url() ?>/public/assets/admin/css/themes/layout/aside/dark.css" rel="stylesheet" type="text/css" />
<!--end::Layout Themes-->
<!-- <link rel="shortcut icon" href="" /> -->