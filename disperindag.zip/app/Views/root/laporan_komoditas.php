<table border="0" style="width: 100%;">
    <tr>
        <?php $logo = base_url('/public/files/web-assets/logo-inhil.png'); ?>
        <td><img src="<?= $logo ?>" width="60px" alt=""></td>
        <td align="center">
            <p style="margin:0; font-size:22px">PEMERINTAH KABUPATEN INDRAGIRI HILIR</p>
            <p style="margin:0; font-size:26px">DINAS PERDAGANGAN DAN PERINDUSTRIAN</p>
            <p style="margin:0">JALAN VETERAN NO. 02 TELP. (0768) 21047 FAX.(0768) 21045</p>
            <p style="margin:0; font-size:22px">TEMBILAHAN</p>
        </td>
    </tr>
</table>
<hr style="height: 5px; background-color:black">
<table border="0" style="width: 100%;">
    <tr>
        <td style="width: 70%; vertical-align: top">
            <table>
                <tr style="vertical-align: top">
                    <td>Nomor</td>
                    <td>:</td>
                    <td>510/Disdagtri-DAG/LAP/2022/</td>
                </tr>
                <tr>
                    <td>Sifat</td>
                    <td>:</td>
                    <td>Biasa</td>
                </tr>
                <tr>
                    <td>Lampiran</td>
                    <td>:</td>
                    <td>-</td>
                </tr>
                <tr>
                    <td>Hal</td>
                    <td>:</td>
                    <td>Harga Harian Bahan Pokok.</td>
                </tr>
            </table>
        </td>
        <td style="width: 30%;">
            <p style="margin: 0; ">Tembilahan, <?= tgl_indo(date('Y-m-d')) ?></p><br>
            <p style="margin: 0;">Kepada Yth,</p>
            <p style="margin: 0;"><b>Bapak Bupati Indragiri Hilir</b></p>
            <p style="margin-top:10px; margin-bottom:10px">di-</p>
            <p style="margin: 0;">
                <center>Tembilahan</center>
            </p>
        </td>
    </tr>
</table>
<p>
    <center>Dengan ini disampaikan hasil pantauan Harga Bahan Pokok dari Pedagang Eceran yang ada di <?= $pasar[0]->pasar_nama ?></center>
</p>
<table class="" border="1" style="border-collapse: collapse; width:100%; margin-top:20px">
    <thead>
        <tr>
            <th rowspan="2" style="width: 50px;">No.</th>
            <th rowspan="2">Varian/Jenis</th>
            <th rowspan="2">Satuan</th>
            <th rowspan="2">HET (Rp)</th>
            <th rowspan="2">Nama Pedagang</th>
            <th colspan="2">Harga (Rp)</th>
            <th colspan="2">Perubahan</th>
            <th rowspan="2">Keterangan</th>
        </tr>
        <tr>
            <th><?= tgl_indo($_GET['awal']) ?></th>
            <th><?= tgl_indo($_GET['akhir']) ?></th>
            <th>Rp</th>
            <th>%</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        foreach ($laporan as $grup) {
        ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><b><?= $grup->grup_komoditas_nama ?></b></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            <?php
            foreach ($grup->komoditas as $komoditas) {
                foreach ($komoditas->transaksi as $row) {
                    $het = $row->transaksi_het;
                    if (is_numeric($het)) {
                        $het = number_format($het);
                    } else {
                        $het = $het;
                    }

                    $perubahan = $row->perubahan;
                    if (is_numeric($perubahan)) {
                        $perubahan = number_format($perubahan);
                    } else {
                        $perubahan = $perubahan;
                    }

                    $transaksi_harga2 = $row->transaksi_harga2;
                    if (is_numeric($transaksi_harga2)) {
                        $transaksi_harga2 = number_format($transaksi_harga2);
                    } else {
                        $transaksi_harga2 = $transaksi_harga2;
                    }
            ?>
                    <tr>
                        <td></td>
                        <td><?= ($row->no == '1' ? $row->komoditas_nama : "") ?></td>
                        <td><?= ($row->no == '1' ? $row->komoditas_satuan : "") ?></td>
                        <td><?= ($row->no == '1' ? $het : "") ?></td>
                        <td><?= $row->pedagang_nama ?></td>
                        <td><?= number_format($row->transaksi_harga) ?></td>
                        <td><?= $transaksi_harga2 ?></td>
                        <td><?= $perubahan ?></td>
                        <td><?= $row->persen; ?></td>
                        <td><?= $row->keterangan ?></td>
                    </tr>

            <?php
                }
            }
            ?>
        <?php
        }
        ?>
    </tbody>
</table>
<table border="0" style="width: 100%; margin-top:20px">
    <tr>
        <td colspan="2" style="padding-left: 50px;">Demikian disampaikan agar dapat dimaklumi</td>
    </tr>
    <tr>
        <td style="width: 40%;"></td>
        <td style="width: 60%;">
            <center>
                <strong>KEPALA DINAS PERDAGANGAN DAN PERINDUSTRIAN</strong><br>
                <strong>KABUPATEN INDRAGIRI HILIR</strong><br><br><br><br><br>
                <strong><u><?= get_nama_kadis() ?></u></strong><br>
                Pembina Tk.I<br>001.
            </center>
        </td>
    </tr>
</table>