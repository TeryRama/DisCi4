<?php

namespace App\Controllers;

use App\Models\Area_model;
use App\Models\Artikel_model;
use App\Models\Barang_lainnya_model;
use App\Models\Barang_penting_model;
use App\Models\Grup_komoditas_model;
use App\Models\Kategori_artikel_model;
use App\Models\Komoditas_model;
use App\Models\Pasar_model;
use App\Models\Transaksi_barang_lainnya_model;
use App\Models\Transaksi_barang_penting_model;
use App\Models\Transaksi_model;

class Publik extends BaseController
{
    function __construct()
    {
        $this->session = \Config\Services::session();
        $this->request = \Config\Services::request();
        $this->db = \Config\Database::connect();

        $this->PM = new Pasar_model();
        $this->AM = new Area_model();
        $this->GKM = new Grup_komoditas_model();
        $this->KM = new Komoditas_model();
        $this->TM = new Transaksi_model();
        $this->KAM = new Kategori_artikel_model();
        $this->ARM = new Artikel_model();
        $this->TBPM = new Transaksi_barang_penting_model();
        $this->BPM = new Barang_penting_model();
        $this->BLM = new Barang_lainnya_model();
        $this->TBLM = new Transaksi_barang_lainnya_model();

        date_default_timezone_set("Asia/Jakarta");
    }

    public function index()
    {
        $data['title'] = "Home";
        $data['panel'] = "home";

        $artikel = $this->ARM->select('*')->join('tb_kategori_artikel', 'tb_artikel.artikel_kategori = tb_kategori_artikel.kategori_id')->where('artikel_status', '1')->where('artikel_akses', 'Published')->orderBy('artikel_create_time', 'DESC')->limit(4)->get()->getResult();
        $data['artikel'] = $artikel;

        return view('public/page_home', $data);
        //echo encrypt_url('2C15CC0F-9017-4A48-9768-3F6701CAB083');
        //echo "<br>";
        //echo encrypt_url("18");
    }

    public function komoditas()
    {
        $data['title'] = "Harga Komoditas";
        $data['panel'] = "komoditas";
        $komoditas = $this->KM->get_all_komoditas();
        $cek_last_update = $this->TM->select('transaksi_tanggal')->groupBy('transaksi_tanggal')->where('transaksi_status', '1')->orderBy('transaksi_tanggal', 'DESC')->limit(2)->get()->getResult();
        if (count($cek_last_update) > 0) {
            $last_update = $cek_last_update[0]->transaksi_tanggal;
            for ($i = 0; $i < count($komoditas); $i++) {
                $avg = $this->TM->get_avg_by_komoditas_date($komoditas[$i]->komoditas_id, $last_update);
                $komoditas[$i]->avg_harga = $avg[0]->rata_harga;
                if (count($cek_last_update) > 1) {
                    $prev_date = $cek_last_update[1]->transaksi_tanggal;
                    $komoditas[$i]->prev_date = $cek_last_update[1]->transaksi_tanggal;
                    $avg_prev_query = $this->TM->get_avg_by_komoditas_date($komoditas[$i]->komoditas_id, $prev_date);
                    $komoditas[$i]->avg_prev =  $avg_prev_query[0]->rata_harga;
                } else {
                    $komoditas[$i]->avg_prev =  $komoditas[$i]->avg_harga;
                    $komoditas[$i]->prev_date = $last_update;
                }

                if ($komoditas[$i]->avg_harga > $komoditas[$i]->avg_prev) {
                    $komoditas[$i]->status =  'Harga Naik';
                } elseif ($komoditas[$i]->avg_harga < $komoditas[$i]->avg_prev) {
                    $komoditas[$i]->status =  'Harga Turun';
                } else {
                    $komoditas[$i]->status =  'Harga Stabil';
                }
            }
        }
        $data['last_update'] = $last_update;
        $data['komoditas'] = $komoditas;



        $penting = $this->BPM->select('barang_id, barang_nama, barang_satuan, barang_foto')->join('tb_grup_komoditas', 'tb_barang_penting.barang_grup = tb_grup_komoditas.grup_komoditas_id')->where('barang_status', '1')->where('grup_komoditas_status', '1')->get()->getResult();
        $cek_last_update_penting = $this->TBPM->select('transaksi_tanggal')->where('transaksi_status', '1')->groupBy('transaksi_tanggal')->orderBy('transaksi_tanggal', 'DESC')->limit(2)->get()->getResult();
        if (count($cek_last_update_penting) > 0) {
            $last_update_penting = $cek_last_update_penting[0]->transaksi_tanggal;
            foreach ($penting as $row) {
                $avg = $this->TBPM->select('ROUND(AVG(transaksi_harga)) as rata_harga, transaksi_tanggal')
                    ->where('transaksi_barang', $row->barang_id)
                    ->where('DATE(transaksi_tanggal)', $last_update_penting)
                    ->where('transaksi_status', '1')
                    ->get()
                    ->getResult();
                $row->avg_harga = $avg[0]->rata_harga;
                if (count($cek_last_update_penting) > 1) {
                    $prev_date = $cek_last_update_penting[1]->transaksi_tanggal;
                    $row->prev_date = $cek_last_update_penting[1]->transaksi_tanggal;
                    $avg_prev_query = $avg = $this->TBPM->select('ROUND(AVG(transaksi_harga)) as rata_harga, transaksi_tanggal')
                        ->where('transaksi_barang', $row->barang_id)
                        ->where('DATE(transaksi_tanggal)', $prev_date)
                        ->where('transaksi_status', '1')
                        ->get()
                        ->getResult();
                    $row->avg_prev =  $avg_prev_query[0]->rata_harga;
                } else {
                    $row->avg_prev =  $row->avg_harga;
                    $row->prev_date = $last_update_penting;
                }
                if ($row->avg_harga > $row->avg_prev) {
                    $row->status =  'Harga Naik';
                } elseif ($row->avg_harga < $row->avg_prev) {
                    $row->status =  'Harga Turun';
                } else {
                    $row->status =  'Harga Stabil';
                }
            }
        }
        $data['barang_penting'] = $penting;
        $data['last_update_penting'] = $last_update_penting;

        $lainnya = $this->BLM->select('barang_id, barang_nama, barang_satuan, barang_foto')->join('tb_grup_komoditas', 'tb_barang_lainnya.barang_grup = tb_grup_komoditas.grup_komoditas_id')->where('barang_status', '1')->where('grup_komoditas_status', '1')->get()->getResult();
        $cek_last_update_lainnya = $this->TBLM->select('transaksi_tanggal')->where('transaksi_status', '1')->groupBy('transaksi_tanggal')->orderBy('transaksi_tanggal', 'DESC')->limit(2)->get()->getResult();
        if (count($cek_last_update_lainnya) > 0) {
            $last_update_lainnya = $cek_last_update_lainnya[0]->transaksi_tanggal;
            foreach ($lainnya as $row) {
                $avg = $this->TBLM->select('ROUND(AVG(transaksi_harga)) as rata_harga, transaksi_tanggal')
                    ->where('transaksi_barang', $row->barang_id)
                    ->where('DATE(transaksi_tanggal)', $last_update_lainnya)
                    ->where('transaksi_status', '1')
                    ->get()
                    ->getResult();
                $row->avg_harga = $avg[0]->rata_harga;
                if (count($cek_last_update_lainnya) > 1) {
                    $prev_date = $cek_last_update_lainnya[1]->transaksi_tanggal;
                    $row->prev_date = $cek_last_update_lainnya[1]->transaksi_tanggal;
                    $avg_prev_query = $avg = $this->TBLM->select('ROUND(AVG(transaksi_harga)) as rata_harga, transaksi_tanggal')
                        ->where('transaksi_barang', $row->barang_id)
                        ->where('DATE(transaksi_tanggal)', $prev_date)
                        ->where('transaksi_status', '1')
                        ->get()
                        ->getResult();
                    $row->avg_prev =  $avg_prev_query[0]->rata_harga;
                } else {
                    $row->avg_prev =  $row->avg_harga;
                    $row->prev_date = $last_update_lainnya;
                }
                if ($row->avg_harga > $row->avg_prev) {
                    $row->status =  'Harga Naik';
                } elseif ($row->avg_harga < $row->avg_prev) {
                    $row->status =  'Harga Turun';
                } else {
                    $row->status =  'Harga Stabil';
                }
            }
        }
        $data['barang_lainnya'] = $lainnya;
        $data['last_update_lainnya'] = $last_update_lainnya;

        $artikel = $this->ARM->select('artikel_id, artikel_judul, artikel_url, artikel_create_time, artikel_gambar, kategori_nama')->join('tb_kategori_artikel', 'tb_artikel.artikel_kategori = tb_kategori_artikel.kategori_id')->where('artikel_status', '1')->where('artikel_akses', 'Published')->orderBy('artikel_create_time', 'DESC')->limit(5)->get()->getResult();
        $data['artikel'] = $artikel;

        return view('public/page_komoditas', $data);
        // echo json_encode($data);
        // exit;
    }


    public function pasar()
    {
        $data['title'] = "Data Pasar";
        $data['panel'] = "data-pasar";
        $data['pasar'] = $this->PM->get_all_pasar();
        for ($i = 0; $i < count($data['pasar']); $i++) {
            $kec = $this->AM->get_area_by_code($data['pasar'][$i]->pasar_kecamatan);
            $kel = $this->AM->get_area_by_code($data['pasar'][$i]->pasar_kelurahan);
            $data["pasar"][$i]->nama_kecamatan = $kec[0]['name'];
            $data["pasar"][$i]->nama_kelurahan = $kel[0]['name'];
        }
        return view('public/page_pasar', $data);
    }

    public function detail_komoditas()
    {
        $id = decrypt_small($this->request->uri->getSegment(2));
        $data['title'] = "Data Komoditas";
        $data['panel'] = "komoditas";
        $data['komoditas'] = $this->KM->get_komoditas_by_id($id);
        $harga = $this->TM->select('ROUND(AVG(tb_transaksi.transaksi_harga)) as rata_harga, tb_transaksi.transaksi_tanggal, tb_pasar.pasar_nama, _area.name')
            ->join('tb_pasar', 'tb_transaksi.transaksi_pasar = tb_pasar.pasar_id')
            ->join('_area', 'tb_pasar.pasar_kecamatan = _area.code')
            ->where('transaksi_komoditas', $id)
            ->where('transaksi_status', '1')
            ->orderBy('transaksi_tanggal', 'DESC')
            ->groupBy('transaksi_tanggal')
            ->limit(1)
            ->get()->getResult();
        $last_update = $harga[0]->transaksi_tanggal;
        $max = $this->TM->select('transaksi_harga')
            ->where('transaksi_komoditas', $id)
            ->where('transaksi_tanggal', $last_update)
            ->where('transaksi_status', '1')
            ->orderBy('transaksi_harga', 'DESC')
            ->limit(1)
            ->get()->getResult();
        $min = $this->TM->select('transaksi_harga')
            ->where('transaksi_komoditas', $id)
            ->where('transaksi_tanggal', $last_update)
            ->where('transaksi_status', '1')
            ->orderBy('transaksi_harga', 'ASC')
            ->limit(1)
            ->get()->getResult();
        $data['komoditas'][0]->komoditas_harga = $harga[0]->rata_harga;
        $data['komoditas'][0]->komoditas_harga_min = $min[0]->transaksi_harga;
        $data['komoditas'][0]->komoditas_harga_max = $max[0]->transaksi_harga;

        $transaksi = $this->TM->select('ROUND(AVG(tb_transaksi.transaksi_harga)) as rata_harga, tb_transaksi.transaksi_tanggal, tb_pasar.pasar_nama, _area.name')
            ->join('tb_pasar', 'tb_transaksi.transaksi_pasar = tb_pasar.pasar_id')
            ->join('_area', 'tb_pasar.pasar_kecamatan = _area.code')
            ->where('transaksi_komoditas', $id)
            ->where('transaksi_status', '1')
            ->where('transaksi_tanggal', $last_update)
            ->orderBy('transaksi_create_time', 'DESC')
            ->groupBy('transaksi_pasar')
            ->get()->getResult();
        $data['transaksi'] = $transaksi;

        $perubahan = $this->TM->select('ROUND(AVG(tb_transaksi.transaksi_harga)) as rata_harga, tb_transaksi.transaksi_tanggal, ROUND(AVG(tb_transaksi.transaksi_het)) as het')
            ->join('tb_pasar', 'tb_transaksi.transaksi_pasar = tb_pasar.pasar_id')
            ->join('_area', 'tb_pasar.pasar_kecamatan = _area.code')
            ->where('transaksi_komoditas', $id)
            ->where('transaksi_status', '1')
            ->where('transaksi_tanggal <=', $last_update)
            ->orderBy('transaksi_create_time', 'DESC')
            ->groupBy('transaksi_tanggal')
            ->limit('5')
            ->get()->getResult();
        $data['perubahan'] = $perubahan;

        $data['last_update'] = $last_update;




        $artikel = $this->ARM->select('artikel_id, artikel_judul, artikel_url, artikel_create_time, artikel_gambar, kategori_nama')->join('tb_kategori_artikel', 'tb_artikel.artikel_kategori = tb_kategori_artikel.kategori_id')->where('artikel_status', '1')->where('artikel_akses', 'Published')->orderBy('artikel_create_time', 'DESC')->limit(5)->get()->getResult();
        $data['artikel'] = $artikel;
        // echo json_encode($data);
        return view('public/page_detail_komoditas', $data);
    }

    public function detail_pasar()
    {
        $id = decrypt_small($this->request->uri->getSegment(2));
        $data['panel'] = "data-pasar";
        $data['pasar'] = $this->PM->get_pasar_by_id($id);
        for ($i = 0; $i < count($data['pasar']); $i++) {
            $kec = $this->AM->get_area_by_code($data['pasar'][$i]->pasar_kecamatan);
            $kel = $this->AM->get_area_by_code($data['pasar'][$i]->pasar_kelurahan);
            $data["pasar"][$i]->nama_kecamatan = $kec[0]['name'];
            $data["pasar"][$i]->nama_kelurahan = $kel[0]['name'];
        }
        $data['title'] = $data['pasar'][0]->pasar_nama;
        return view('public/page_detail_pasar', $data);
    }

    public function statistik_wilayah()
    {
        $data['panel'] = "statistik_wilayah";
        $data['title'] = "Statistik Wilayah";
        $data['kecamatan'] = $this->AM->get_all_kecamatan();
        $data['pasar'] = $this->PM->get_all_pasar();
        $artikel = $this->ARM->select('artikel_id, artikel_judul, artikel_url, artikel_create_time, artikel_gambar, kategori_nama')->join('tb_kategori_artikel', 'tb_artikel.artikel_kategori = tb_kategori_artikel.kategori_id')->where('artikel_status', '1')->where('artikel_akses', 'Published')->orderBy('artikel_create_time', 'DESC')->limit(5)->get()->getResult();
        $data['artikel'] = $artikel;

        if (!isset($_GET['bulan']) || $_GET['bulan'] == "" || !isset($_GET['tahun']) || $_GET['tahun'] == "") {
            $mn = date('m');
            $yn = date('Y');
            $first = $yn . '-' . $mn . '01';
            $last = $yn . '-' . $mn . '31';
        } else {
            $mn = $_GET['bulan'];
            $yn = $_GET['tahun'];
            $first = $yn . '-' . $mn . '01';
            $last = $yn . '-' . $mn . '31';
        }

        $get_tanggal = $this->TM
            ->select('transaksi_tanggal')
            ->where('transaksi_status', '1')
            ->where('YEAR(transaksi_tanggal)', $yn)
            ->where('MONTH(transaksi_tanggal)', $mn)
            ->groupBy('transaksi_tanggal')
            ->get()->getResult();
        $data['tanggal'] = $get_tanggal;
        $komoditas = $this->KM->select('komoditas_id, komoditas_nama')->join('tb_grup_komoditas', 'tb_komoditas.komoditas_grup = tb_grup_komoditas.grup_komoditas_id')->where('komoditas_status', '1')->where('grup_komoditas_status', '1')->get()->getResult();
        foreach ($komoditas as $row) {

            $harga = array();
            foreach ($get_tanggal as $r) {

                $transaksi = $this->TM
                    ->select('ROUND(AVG(tb_transaksi.transaksi_harga)) as rata_harga')
                    ->where('transaksi_komoditas', $row->komoditas_id)
                    ->where('DATE(transaksi_tanggal)', $r->transaksi_tanggal)
                    ->where('transaksi_status', '1')
                    ->groupBy('transaksi_tanggal')
                    ->get()->getResult();
                if (count($transaksi) > 0) {
                    array_push($harga, $transaksi[0]->rata_harga);
                } else {
                    array_push($harga, "-");
                }
            }
            $row->harga = $harga;
        }
        $data['komoditas'] = $komoditas;
        return view('public/page_statistik_wilayah', $data);
        // echo json_encode($data);
    }

    public function statistik_komoditas()
    {
        $data['panel'] = "statistik_komoditas";
        $data['title'] = "Statistik Komoditas";
        $data['komoditas'] = $this->KM->get_all_komoditas();
        return view('public/page_statistik_komoditas', $data);
    }



    public function disperindag()
    {
        $data['panel'] = "disperindag";
        $data['title'] = "DISPERINDAG";
        return view('public/page_disperindag', $data);
    }

    public function privasi()
    {
        $data['panel'] = "";
        $data['title'] = "Kebijakan Privasi";
        return view('public/page_privasi', $data);
    }
}
